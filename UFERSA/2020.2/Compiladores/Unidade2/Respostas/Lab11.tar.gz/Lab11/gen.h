
#ifndef COMPILER_GENERATOR
#define COMPILER_GENERATOR

#include "ast.h"

Expression * Lvalue(Expression * n);
Expression * Rvalue(Expression * n);

#endif
