#ifndef COMPILER_CHECKER
#define COMPILER_CHECKER

#include "ast.h"

void TestLexer();
void TestParser(Node *);

#endif